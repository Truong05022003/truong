@extends('masters.uniformMaster')

@section('main')
  <div class="container">
    <h1 class="display-4">New ClassRoom</h1>

    @include('partials.errors')

    <form action="{{route('category.manager')}}" method="post" enctype="multipart/form-data">
      @csrf
      <div class="form-group">
        <label for="name" class="font-weight-bold">Name </label>
        <input type="text" class="form-control" id="name" name="name" value="{{old('name')}}">
      </div>

      <div class="form-group">
        <label for="img" class="font-weight-bold">img</label>
        <input type="file" class="form-control" id="img" name="file_upload" value="{{old('img')}}">
      </div>

      <div class="form-group">
        <label for="description" class="font-weight-bold">description</label>
        <input type="text" class="form-control" id="description" name="description" value="{{old('description')}}">
      </div>
      <br>
      <button type="submit" class="btn btn-primary">Add new classroom</button>
      <button type="reset" class="btn btn-secondary">Reset</button>
    </form>
  </div>
@endsection
