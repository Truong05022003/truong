@extends('masters.uniformMaster')

@section('main')
   <div class="container">
      <h1 class="display-4">Update An Existing Category</h1>

      {{--    {{var_dump(\Illuminate\Support\Facades\Session::all())}}--}}

      @include('partials.errors')

      <form action="{{route('category.update', ['id' => old('catID')?? $cat->catID])}}" method="post">
         @csrf

         <input type="hidden" name="catID" value="{{old('catID')?? $cat->catID}}">
         <div class="form-group">
            <label for="name" class="font-weight-bold">name</label>
            <input type="text" class="form-control" id="name" name="name"
                   value="{{old('name')?? $cat->name}}">
         </div>

         <div class="form-group">
            <label for="img" class="font-weight-bold">img</label>
            <input type="file" class="form-control" id="img" name="img"
                   value="{{old('img')?? $cat->img}}">
         </div>

         <div class="form-group">
            <label for="description" class="font-weight-bold">description</label>
            <input type="text" class="form-control" id="Size" name="description"
                   value="{{old('description')?? $cat->description}}">
         </div>
         <br>
         <button type="submit" class="btn btn-primary">Update</button>
         <button type="reset" class="btn btn-secondary">Reset</button>

      </form>
   </div>
@endsection
