<dl class="row">
  <dt class="col-sm-3">ID</dt>
  <dd class="col-sm-9">{{ $cat->catID }}</dd>

  <dt class="col-sm-3">name</dt>
  <dd class="col-sm-9">{{ $cat->name }}</dd>

  <dt class="col-sm-3">Img</dt>
  <dd class="col-sm-9"><img src="{{url('uploads')}}/{{$cat->img}}" width="200"></dd>

  <dt class="col-sm-3">description</dt>
  <dd class="col-sm-9">{{$cat->description }}</dd>
</dl>
