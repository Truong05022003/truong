@extends('masters.uniformMaster')

@section('main')
  <div class="container">
{{--    @include('classRoom.classSession.mess')--}}
    <br>
    <table class="table table-hover">
      <thead class="thead-dark">
      <tr>
        <th scope="col">#</th>
        <th scope="col">Name </th>
        <th scope="col">img</th>
        <th scope="col">description</th>
        <th scope="col">&nbsp;</th>
        <th scope="col">&nbsp;</th>
        <th scope="col">&nbsp;</th>
      </tr>
      </thead>
      <tbody>
      @foreach($cat as $c)
        <tr>
          <th scope="row">{{$c->catID}}</th>
          <td>{{$c->name}}</td>
          <td> <img src="{{url('uploads')}}/{{$c->img}}" width="60"></td>
          <td>{{$c->description}}</td>
          <td><a type="button" class="btn btn-primary btn-sm"
                 href="{{route('category.show', ['id' => $c->catID])}}"
            >Details</a>
          <td><a type="button" class="btn btn-success btn-sm"
                 href="{{route('category.edit', ['id' => $c->catID])}}"
            >Edit</a></td>
          <td><a type="button" class="btn btn-danger btn-sm"
                 href="{{route('category.confirm', ['id' => $c->catID])}}"
            >Delete</a></td>
        </tr>
      @endforeach
      </tbody>
    </table>

@endsection
