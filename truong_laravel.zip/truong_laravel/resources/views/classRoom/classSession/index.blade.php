@extends('masters.classRoomMaster')

@section('main')
   <div class="container">
     @include('classRoom.classSession.mess')
      <br>
      <table class="table table-hover">
         <thead class="thead-dark">
         <tr>
            <th scope="col">#</th>
            <th scope="col">Name Class</th>
            <th scope="col">Start Date</th>
            <th scope="col">Size</th>
            <th scope="col">&nbsp;</th>
            <th scope="col">&nbsp;</th>
            <th scope="col">&nbsp;</th>
         </tr>
         </thead>
         <tbody>
         @foreach($class as $c)
            <tr>
               <th scope="row">{{$c->id}}</th>
               <td>{{$c->NAME}}</td>
               <td>{{$c->StartDate}}</td>
               <td>{{$c->Size}}</td>
              <td><a type="button" class="btn btn-primary btn-sm"
                     href="{{route('classRooms.show', ['id' => $c->id])}}"
                >Details</a>
              </td>
               <td><a type="button" class="btn btn-success btn-sm"
                      href="{{route('classRooms.edit', ['id' => $c->id])}}">Edit</a></td>
               <td><a type="button" class="btn btn-danger btn-sm"
                      href="{{route('classRooms.confirm', ['id' => $c->id])}}">Delete</a></td>
            </tr>
         @endforeach
         </tbody>
      </table>
   <a href="{{route('classRooms.create')}}">Create new classroom</a>
@endsection

