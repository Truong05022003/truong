@extends('masters.classRoomMaster')

@section('main')
   <div class="container">
      <h1 class="display-4">Update An Existing ClassRoom</h1>

      {{--    {{var_dump(\Illuminate\Support\Facades\Session::all())}}--}}

      @include('partials.errors')

      <form action="{{route('classRooms.update', ['id' => old('id')?? $class->id])}}" method="post">
         @csrf

         <input type="hidden" name="id" value="{{old('id')?? $class->id}}">
         <div class="form-group">
            <label for="NAME" class="font-weight-bold">Name ClassRoom</label>
            <input type="text" class="form-control" id="NAME" name="NAME"
                   value="{{old('NAME')?? $class->NAME}}">
         </div>

         <div class="form-group">
            <label for="StartDate" class="font-weight-bold">Start Date</label>
            <input type="date" class="form-control" id="StartDate" name="StartDate"
                   value="{{old('StartDate')?? $class->StartDate}}">
         </div>

         <div class="form-group">
            <label for="Size" class="font-weight-bold">Size</label>
            <input type="number" class="form-control" id="Size" name="Size"
                   value="{{old('Size')?? $class->Size}}">
         </div>
         <br>
         <button type="submit" class="btn btn-primary">Update ClassRoom</button>
         <button type="reset" class="btn btn-secondary">Reset</button>

      </form>
   </div>
@endsection
