@extends('masters.classRoomMaster')

@section('main')


  <div class="container">
    <h1 class="display-4">Book Details</h1>
    @include('classRoom.classSession.classDetails')
    <a type="button" href="{{route('classRooms.index')}}" class="btn btn-info">&lt;&lt;&nbsp;Index</a>
  </div>
@endsection
