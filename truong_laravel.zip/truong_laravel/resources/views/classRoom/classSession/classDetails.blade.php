<dl class="row">
  <dt class="col-sm-3">ID</dt>
  <dd class="col-sm-9">{{ $class->id }}</dd>

  <dt class="col-sm-3">Title</dt>
  <dd class="col-sm-9">{{ $class->NAME }}</dd>

  <dt class="col-sm-3">Author</dt>
  <dd class="col-sm-9">{{ $class->StartDate }}</dd>

  <dt class="col-sm-3">Pages</dt>
  <dd class="col-sm-9">{{$class->Size }}</dd>
</dl>
