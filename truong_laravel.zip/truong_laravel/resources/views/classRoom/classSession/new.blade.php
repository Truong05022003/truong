@extends('masters.classRoomMaster')

@section('main')
   <div class="container">
      <h1 class="display-4">New ClassRoom</h1>

      @include('partials.errors')

      <form action="{{route('classRooms.manager')}}" method="post">
         @csrf
         <div class="form-group">
            <label for="NAME" class="font-weight-bold">Name ClassRoom</label>
            <input type="text" class="form-control" id="NAME" name="NAME" value="{{old('NAME')}}">
         </div>

         <div class="form-group">
            <label for="StartDate" class="font-weight-bold">Start Date</label>
            <input type="date" class="form-control" id="StartDate" name="StartDate" value="{{old('StartDate')}}">
         </div>

         <div class="form-group">
            <label for="Size" class="font-weight-bold">Size</label>
            <input type="number" class="form-control" id="Size" name="Size" value="{{old('Size')}}">
         </div>
         <br>
         <button type="submit" class="btn btn-primary">Add new classroom</button>
         <button type="reset" class="btn btn-secondary">Reset</button>
      </form>
   </div>
@endsection
