<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title></title>
  {{--  <link rel="stylesheet" href="{{asset('bootstrap1/css/bootstrap.min.css')}}">--}}
  {{--  <link rel="stylesheet" href="{{asset('bootstrap1/css/bootstrap-icons.css')}}">--}}

  {{--online bootsrap--}}

  <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
        integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l"
        crossorigin="anonymous">
  <link rel="stylesheet" href="{{asset('css/style.css')}}">
</head>
<body>
<header>
  @include('partials.homepageNav')
</header>



<main role="main">
  @yield('main')
</main>

{{--<script src="{{asset('bootstrap1/js/jquery-3.6.0.min.js')}}"></script>--}}
{{--<script src="{{asset('bootstrap1/js/bootstrap.min.js')}}"></script>--}}

{{--Online JS and Bootstrap}}--}}

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js"
        integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF"
        crossorigin="anonymous"></script>

@yield('script')
</body>
</html>
