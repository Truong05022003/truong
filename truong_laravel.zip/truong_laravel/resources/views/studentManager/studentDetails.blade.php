<dl class="row">
  <dt class="col-sm-3">ID</dt>
  <dd class="col-sm-9">{{ $student->id }}</dd>

  <dt class="col-sm-3">Title</dt>
  <dd class="col-sm-9">{{ $student->name }}</dd>

  <dt class="col-sm-3">Author</dt>
  <dd class="col-sm-9">{{ $student->email }}</dd>

  <dt class="col-sm-3">Pages</dt>
  <dd class="col-sm-9">{{$student->contact }}</dd>

  <dt class="col-sm-3">class</dt>
  <dd class="col-sm-9">{{$class->NAME}}</dd>
</dl>
