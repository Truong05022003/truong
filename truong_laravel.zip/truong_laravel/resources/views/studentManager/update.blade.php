@extends('masters.studentMaster')

@section('main')
   <div class="container">
      <h1 class="display-4">Update An Existing Student</h1>

      {{--    {{var_dump(\Illuminate\Support\Facades\Session::all())}}--}}

      @include('partials.errors')

      <form action="{{route('student.update', ['id' => old('id')?? $student->id])}}" method="post">
         @csrf

         <input type="hidden" name="id" value="{{old('id')?? $student->id}}">
         <div class="form-group">
            <label for="name" class="font-weight-bold">Name Student</label>
            <input type="text" class="form-control" id="name" name="name"
                   value="{{old('name')?? $student->name}}">
         </div>

         <div class="form-group">
            <label for="email" class="font-weight-bold">Email</label>
            <input type="email" class="form-control" id="email" name="email"
                   value="{{old('email')?? $student->email}}">
         </div>

         <div class="form-group">
            <label for="contact" class="font-weight-bold">Contact</label>
            <input type="number" class="form-control" id="contact" name="contact"
                   value="{{old('contact')?? $student->contact}}">
         </div>
        @php
          $pId = old('class') ?? $student->studentID?? null;
        @endphp
        <div class="form-group">
          <label for="class" class="font-weight-bold">class</label>
          <select name="class" class="form-control" id="class" required>
            <option value="0">Please select a class :)</option>
            @foreach($class as $c)
              <option value="{{ $c->id }}"
                {{ ($pId != null && $c->id == $pId) ? 'selected' : '' }}
              >{{ $c->NAME }}</option>
            @endforeach
          </select>
        </div>
         <br>
         <button type="submit" class="btn btn-primary">Update Student</button>
         <button type="reset" class="btn btn-secondary">Reset</button>

      </form>
   </div>
@endsection
