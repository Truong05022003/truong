@extends('masters.teacherMaster')

@section('main')
   <div class="container">
      <h1 class="display-4">Update An Existing Teacher</h1>

      {{--    {{var_dump(\Illuminate\Support\Facades\Session::all())}}--}}

      @include('partials.errors')

      <form action="{{route('teacher.update', ['teacherID' => old('teacherID')?? $teacher->teacherID])}}" method="post">
         @csrf
         <input type="hidden" name="teacherID" value="{{old('teacherID')?? $teacher->teacherID}}">
         <div class="form-group">
            <label for="name" class="font-weight-bold">Teacher Name</label>
            <input type="text" class="form-control" id="name" name="name"
                   value="{{old('name')?? $teacher->name}}">
         </div>

         <div class="form-group">
            <label for="dob" class="font-weight-bold">Date of Birth</label>
            <input type="date" class="form-control" id="dob" name="dob"
                   value="{{old('dob')?? $teacher->dob}}">
         </div>

         <div class="form-group">
            <label for="ssID" class="font-weight-bold">ssID</label>
            <input type="number" class="form-control" id="ssID" name="ssID"
                   value="{{old('ssID')?? $teacher->ssID}}">
         </div>
        @php
          $fIds = old('selectedF')?? array_column($selectedF, 'id') ?? array();
        @endphp
        <div class="form-group">
          <label class="font-weight-bold mr-3">class</label>
          @foreach($class as $c)
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" value="{{$c->id}}" id="{{$c->NAME}}" name="selectedF[]"
                {{in_array($c->id, $fIds) ? 'checked' : ''}}
              >
              <label class="form-check-label" for="{{$c->NAME}}">
                {{$c->NAME}}
              </label>
            </div>
          @endforeach
        </div>
         <br>
         <button type="submit" class="btn btn-primary">Update Teacher</button>
         <button type="reset" class="btn btn-secondary">Reset</button>

      </form>
   </div>
@endsection
