<dl class="row">
  <dt class="col-sm-3">ID</dt>
  <dd class="col-sm-9">{{ $teacher->teacherID}}</dd>

  <dt class="col-sm-3">Title</dt>
  <dd class="col-sm-9">{{ $teacher->name }}</dd>

  <dt class="col-sm-3">Author</dt>
  <dd class="col-sm-9">{{ $teacher->dob }}</dd>

  <dt class="col-sm-3">Pages</dt>
  <dd class="col-sm-9">{{$teacher->ssID }}</dd>

  <dt class="col-sm-3">class</dt>
  <dd class="col-sm-9">
    @foreach($class as $c)
      <div class="row">
        <div class="col-sm">{{$c->NAME}}</div>
      </div>
    @endforeach
  </dd>
</dl>
