@extends('masters.teacherMaster')

@section('main')
  <div class="container">
    <h1 class="display-4">Are you sure you want to delete?</h1>
    @include('teacherManager.teacherDetails')

    <form action="{{route('teacher.destroy', ['teacherID' =>$teacher->teacherID])}}" method="post">
      @csrf
      <input type="hidden" name="teacherID" value="{{$teacher->teacherID}}">
      <button type="submit" class="btn btn-danger">Delete</button>
      <a href="{{route('teacher.index')}}" class="btn btn-info">Cancel</a>
    </form>
  </div>
@endsection
