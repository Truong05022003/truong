@extends('masters.teacherMaster')

@section('main')
   <div class="container">
     @include('teacherManager.mess')
      <br>
      <table class="table table-hover">
         <thead class="thead-dark">
         <tr>
            <th scope="col">#</th>
            <th scope="col">Teacher Name</th>
            <th scope="col">Date of Birth</th>
            <th scope="col">ssID</th>
            <th scope="col">&nbsp;</th>
            <th scope="col">&nbsp;</th>
            <th scope="col">&nbsp;</th>
         </tr>
         </thead>
         <tbody>
         @foreach($teacher as $t)
            <tr>
               <th scope="row">{{$t->teacherID}}</th>
               <td>{{$t->name}}</td>
               <td>{{$t->dob}}</td>
               <td>{{$t->ssID}}</td>
              <td><a type="button" class="btn btn-primary btn-sm"
                     href="{{route('teacher.show', ['teacherID' => $t->teacherID])}}"
                >Details</a>
               <td><a type="button" class="btn btn-success btn-sm"
                      href="{{route('teacher.edit', ['teacherID' => $t->teacherID])}}"
                 >Edit</a></td>
               <td><a type="button" class="btn btn-danger btn-sm"
                      href="{{route('teacher.confirm', ['teacherID' => $t->teacherID])}}"
                 >Delete</a></td>
            </tr>
         @endforeach
         </tbody>
     </table>
   <a href="{{route('teacher.create')}}">Create new teacher</a>
@endsection


