@extends('masters.teacherMaster')

@section('main')


  <div class="container">
    <h1 class="display-4">Book Details</h1>
    @include('teacherManager.teacherDetails')
    <a type="button" href="{{route('.index')}}" class="btn btn-info">&lt;&lt;&nbsp;Index</a>
  </div>
@endsection
