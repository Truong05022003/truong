<?php

namespace App\Repository;

use Illuminate\Support\Facades\DB;

class studentRepos
{
    public static function getAllstudent() {
        $sql = 'select s.* ';
        $sql .= 'from student as s ';
        $sql .= 'order by s.name';

        return DB::select ($sql);
    }
    public static function getAllstudentWithclass() {
        $sql = 'select s.*, c.name as className ';
        $sql .= 'from student as s ';
        $sql .= 'join classroom as c on s.studentId = c.id ';
        $sql .= 'order by s.name';

        return DB::select ($sql);

    }
    public static function getstudentById($id){
        $sql = 'select s.* ';
        $sql .= 'from student as s ';
        $sql .= 'where s.id = ? ';

        return DB::select($sql, [$id]);
    }

    public static function insert($student){
        $sql = 'insert into student ';
        $sql .= '(name, email, contact,studentID) ';
        $sql .= 'values (?, ?, ?, ?) ';

        $result =  DB::insert($sql, [$student->name, $student->email, $student->contact,$student->studentID]);
        if($result){
            return DB::getPdo()->lastInsertId();
        } else {
            return -1;
        }
    }
    public static function update($student){
        $sql = 'update student ';
        $sql .= 'set name = ?, email = ?, contact = ?, studentID = ? ';
        $sql .= 'where id = ? ';

        DB::update($sql, [$student->name, $student->email, $student->contact,$student->studentID, $student->id]);

    }
    public static function delete($id){
        $sql = 'delete from student ';
        $sql .= 'where id = ? ';

        DB::delete($sql, [$id]);
    }

}
