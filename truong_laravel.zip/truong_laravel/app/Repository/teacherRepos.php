<?php

namespace App\Repository;

use Illuminate\Support\Facades\DB;

class teacherRepos
{
    public static function getAllteacher()
    {
        $sql = 'select t.* ';
        $sql .= 'from teacher as t ';
        $sql .= 'order by t.name';

        return DB::select($sql);
    }

    public static function getteacherById($id)
    {
        $sql = 'select t.* ';
        $sql .= 'from teacher as t ';
        $sql .= 'where t.teacherID = ? ';

        return DB::select($sql, [$id]);
    }

    public static function insert($teacher)
    {
        $sql = 'insert into teacher ';
        $sql .= '(name, dob, ssID) ';
        $sql .= 'values (?, ?, ?) ';

        $result = DB::insert($sql, [$teacher->name, $teacher->dob, $teacher->ssID]);
        if ($result) {
            return DB::getPdo()->lastInsertId();
        } else {
            return -1;
        }
    }
    public static function update($teacher){
        $sql = 'update teacher ';
        $sql .= 'set name = ?, dob = ?, ssID = ? ';
        $sql .= 'where teacherID = ? ';

        DB::update($sql, [$teacher->name, $teacher->dob, $teacher->ssID, $teacher->teacherID]);

    }
    public static function delete($id){
        $sql = 'delete from teacher ';
        $sql .= 'where teacherID = ? ';
        DB::delete($sql, [$id]);
    }

}

