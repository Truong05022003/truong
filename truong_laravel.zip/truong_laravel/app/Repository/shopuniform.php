<?php

namespace App\Repository;

use Illuminate\Support\Facades\DB;

class shopuniform
{

    public static function getAllcategory() {
        $sql = 'select c.* ';
        $sql .= 'from category as c ';
        $sql .= 'order by c.name';

        return DB::select ($sql);
    }
    public static function getcatById($id){
        $sql = 'select c.* ';
        $sql .= 'from category as c ';
        $sql .= 'where c.catID = ? ';

        return DB::select($sql, [$id]);
    }

    public static function insert($cat){
        $sql = 'insert into category ';
        $sql .= '(name, img, description) ';
        $sql .= 'values (?, ?, ?) ';

        $result =  DB::insert($sql, [$cat ->name, $cat ->img, $cat ->description]);
        if($result){
            return DB::getPdo()->lastInsertId();
        } else {
            return -1;
        }
    }
    public static function update($cat){
        $sql = 'update category ';
        $sql .= 'set name = ?, img = ?, description = ? ';
        $sql .= 'where catID = ? ';

        DB::update($sql, [$cat->name, $cat->img, $cat->description, $cat->catID]);

    }
    public static function delete($id){
        $sql = 'delete from category ';
        $sql .= 'where catID = ? ';

        DB::delete($sql, [$id]);
    }
//    public static function getclassBystudentId($studentId){
//        $sql = 'select c.* ';
//        $sql .= 'from classroom as c ';
//        $sql .= 'join student as s on c.id = s.studentId ';
//        $sql .= 'where s.id = ?';
//
//        return DB::select($sql, [$studentId]);
//    }
//    public static function insertteacherclassRelationship($classId, $selectedF)
//    {
//        foreach ($selectedF as $fId) {
//            $sql = 'insert into teacher_class ';
//            $sql .= '(IDteacher, classID) ';
//            $sql .= 'values (?, ?) ';
//
//            DB::insert($sql, [$classId, $fId]);
//        }
//    }
//    public static function getclassbyteacherID($teacherID)
//    {
//        $sql = 'select tc.IDteacher, c.id, c.NAME ';
//        $sql .= 'from classroom as c ';
//        $sql .= 'join teacher_class as tc on c.id = tc.classID ';
//        $sql .= 'where tc.IDteacher = ? ';
//
//        return DB::select($sql, [$teacherID]);
//    }
//    public static function deleteteacherclassRelationship($teacherID)
//    {
//
//        $sql = 'delete from teacher_class ';
//        $sql .= 'where IDteacher = ? ';
//
//        DB::delete($sql, [$teacherID]);
//
//    }
}
