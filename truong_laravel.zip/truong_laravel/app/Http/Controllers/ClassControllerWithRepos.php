<?php

namespace App\Http\Controllers;

use App\Repository\classRepos;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ClassControllerWithRepos extends Controller
{
    public function index()
        {
            $cat = classRepos::getAllcategory();
            return view('shop_uniform.index',
                [
                    'class' => $cat,
                ]);
        }
    public function show($id)
    {

        $class  = classRepos::getclassById($id); //this is always an array of objects
        return view('classRoom.classSession.show',
            [
                'class' => $class[0] //get the first element
            ]
        );
    }
    public function create()
    {

        return view(
            'classRoom.classSession.new',
            ["class" => (object)[
                'id' => '',
                'NAME' => '',
                'StartDate' => '',
                'Size' => 0
            ]]);

    }
    public function manager(Request $request)
    {
        $this->formValidate($request)->validate(); //shortcut

        $class  = (object)[
            'NAME' => $request->input('NAME'),
            'StartDate' => $request->input('StartDate'),
            'Size' => $request->input('Size'),
        ];

        $newId = classRepos::insert($class);

        return redirect()
            ->action('ClassControllerWithRepos@index')
            ->with('msg', 'New class with id: '.$newId.' has been inserted');
    }
    public function edit($id)
    {
        $class = classRepos::getclassById($id); //this is always an array


        return view(
            'classRoom.classSession.update',
            ["class" => $class[0]]);
    }
    public function update(Request $request, $id)
    {
        if ($id != $request->input('id')) {
            //id in query string must match id in hidden input
            return redirect()->action('ClassControllerWithRepos@index');
        }

        $this->formValidate($request)->validate(); //shortcut

        $class= (object)[
            'id' => $request->input('id'),
            'NAME' => $request->input('NAME'),
            'StartDate' => $request->input('StartDate'),
            'Size' => $request->input('Size'),
        ];
        classRepos::update($class);

        return redirect()->action('ClassControllerWithRepos@index')
            ->with('msg', 'Update Successfully');
    }
    public function confirm($id){
        $class = classRepos::getclassById($id); //this is always an array

        return view('classRoom.classSession.confirm',
            [
                'class' => $class[0]
            ]
        );
    }
    public function destroy(Request $request, $id)
    {
        if ($request->input('id') != $id) {
            //id in query string must match id in hidden input
            return redirect()->action('ClassControllerWithRepos@index');
        }

        classRepos::delete($id);


        return redirect()->action('ClassControllerWithRepos@index')
            ->with('msg', 'Delete Successfully');
    }


    private function formValidate($request)
    {
        return Validator::make(
            $request->all(),
            [
                'StartDate' => ['required', 'date', 'after:01/01/2000'],
                'Size' => ['required', 'numeric', 'min:13'],
                'NAME' => ['required', 'min:6', 'max:8',
                    'starts_with:C',
//               function ($attribute, $value, $fail) {
//
//                  $month = date('m');
//                  $year = date('y');
//                  if (($value[2] == $year[0]) && ($value[3] == $year[1]))
//                  {
//                     $fail('The next 4 digits are year of birth and month of birth');
//                  }
//                  if (($value[4] == $month[0]) && ($value[5] == $month[1]))
//                  {
//                     $fail('The next 4 digits are year of birth and month of birth');
//                  }
//                  if ($value[6] == 'G' || $value[6] == 'I' || $value[6] == 'L')
//                  {
//                     $fail('The sixth character must be either G, I or L');
//                  }
//               }
                ]
            ],
            [
                //change validation message
                'nameClass.starts_with' => 'Name Class must start with letter C'
            ]
        );
    }
}
