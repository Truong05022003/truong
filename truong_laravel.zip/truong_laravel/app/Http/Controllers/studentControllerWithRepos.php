<?php

namespace App\Http\Controllers;

use App\Repository\classRepos;
use App\Repository\studentRepos;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class studentControllerWithRepos extends Controller
{
    public function index()
    {
//        $student = studentRepos::getAllstudent();
        $student = studentRepos::getAllstudentWithclass();
        return view('studentManager.index',
            [
                'student' => $student,
            ]);
    }
    public function show($id)
    {
        $class = classRepos::getclassBystudentId($id);
        $student = studentRepos::getstudentById($id); //this is always an array of objects
        return view('studentManager.show',
            [
                'student' => $student[0],
                'class'=>$class[0]//get the first element
            ]
        );
    }

    public function create()
    {
        $class = classRepos::getAllclass();
        return view(
            'studentManager.new',
            ["student" => (object)[
                'id' => '',
                'name' => '',
                'email' => '',
                'contact' => 0,
                'studentID'=>''
            ],
                "class" => $class
            ]);

    }

    public function manager(Request $request)
    {
        $this->formValidate($request)->validate(); //shortcut

        $student = (object)[
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'contact' => $request->input('contact'),
            'studentID' => $request->input('class')
        ];

        $newId = studentRepos::insert($student);

        return redirect()
            ->action('studentControllerWithRepos@index')
            ->with('msg', 'New book with id: '.$newId.' has been inserted');
    }

    public function edit($id)
    {
        $student = studentRepos::getstudentById($id); //this is always an array
        $class = classRepos::getAllclass();

        return view(
            'studentManager.update',
            ["student" => $student[0],
                "class"=>$class
            ]);
    }
    public function update(Request $request, $id)
    {
        if ($id != $request->input('id')) {
            //id in query string must match id in hidden input
            return redirect()->action('studentControllerWithRepos@index');
        }

        $this->formValidate($request)->validate(); //shortcut

        $student = (object)[
            'id' => $request->input('id'),
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'contact' => $request->input('contact'),
            'studentID'=>$request->input('class'),
        ];
        studentRepos::update($student);

        return redirect()->action('studentControllerWithRepos@index')
            ->with('msg', 'Update Successfully');;
    }
    public function confirm($id){
        $student = studentRepos::getstudentById($id); //this is always an array
        $class = classRepos::getclassBystudentId($id);
        return view('studentManager.confirm',
            [
                'student' => $student[0],
                'class'=>$class[0]
            ]
        );
    }

    public function destroy(Request $request, $id)
    {
        if ($request->input('id') != $id) {
            //id in query string must match id in hidden input
            return redirect()->action('studentControllerWithRepos@index');
        }

        studentRepos::delete($id);


        return redirect()->action('studentControllerWithRepos@index')
            ->with('msg', 'Delete Successfully');
    }

    private function formValidate($request)
    {
        return Validator::make(
            $request->all(),
            [
                'name' => ['required'],
                'email' => ['required', 'email'],
                'contact' => ['required', 'size:10', 'starts-with:0'],
                'class'=>['gt:0']

            ],
            ['class.gt' => 'please select a class'
                ]
        );
    }

}
