<?php

namespace App\Http\Controllers;

use App\Repository\classRepos;
use App\Repository\studentRepos;
use App\Repository\teacherRepos;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class teacherControllerWithRepos extends Controller
{
    public function index()
    {
        $teacher = teacherRepos::getAllteacher();
        return view('teacherManager.index',
            [
                'teacher' => $teacher,
            ]);
    }

    public function show($id)
    {
        $class =   classRepos::getclassbyteacherID($id);
        $teacher = teacherRepos::getteacherById($id); //this is always an array of objects
        return view('teacherManager.show',
            [
                'teacher' => $teacher[0],
                'class'=>$class//get the first element
            ]
        );
    }

    public function create()
    {
        $class = classRepos::getAllclass();
        return view(
            'teacherManager.new',
            ["teacher" => (object)[
                'teacherID' => '',
                'name' => '',
                'dob' => 0,
                'ssID' => 0
            ],
                'class'=>$class,
                'selectedF'=>[],
            ]);

    }

    public function manager(Request $request)
    {
        $this->formValidate($request)->validate(); //shortcut

        $teacher = (object)[
            'name' => $request->input('name'),
            'dob' => $request->input('dob'),
            'ssID' => $request->input('ssID'),
        ];

        $newId = teacherRepos::insert($teacher);
        $selectedF = $request->input('selectedF');
        classRepos::insertteacherclassRelationship($newId, $selectedF);
        return redirect()
            ->action('teacherControllerWithRepos@index')
            ->with('msg', 'New book with id: ' . $newId . ' has been inserted');
    }

    public function edit($id)
    {
        $teacher = teacherRepos::getteacherById($id); //this is always an array
        $class = classRepos::getAllclass();
        $selectedF = classRepos::getclassbyteacherID($id);
        return view(
            'teacherManager.update',
            ["teacher" => $teacher[0],
                'class'=>$class,
                'selectedF'=>$selectedF
            ]);
    }
    public function update(Request $request, $id)
    {
        if ($id != $request->input('teacherID')) {
            //id in query string must match id in hidden input
            return redirect()->action('teacherControllerWithRepos@index');
        }

        $this->formValidate($request)->validate(); //shortcut

        $teacher = (object)[
            'teacherID' => $request->input('teacherID'),
            'name' => $request->input('name'),
            'dob' => $request->input('dob'),
            'ssID' => $request->input('ssID'),
        ];
        teacherRepos::update($teacher);
        $selectedF = $request->input('selectedF');
        classRepos::deleteteacherclassRelationship($teacher->teacherID);
        classRepos::insertteacherclassRelationship($teacher->teacherID, $selectedF);

        return redirect()->action('teacherControllerWithRepos@index')
            ->with('msg', 'Update Successfully');
    }
    public function confirm($id){
        $teacher = teacherRepos::getteacherById($id); //this is always an array
        $class =   classRepos::getclassbyteacherID($id);
        return view('teacherManager.confirm',
            [
                'teacher' => $teacher[0],
                'class'=>$class

            ]
        );
    }

    public function destroy(Request $request, $id)
    {
        if ($request->input('teacherID') != $id) {
            //id in query string must match id in hidden input
            return redirect()->action('teacherControllerWithRepos@index');
        }
        classRepos::deleteteacherclassRelationship($id);
        teacherRepos::delete($id);


        return redirect()->action('teacherControllerWithRepos@index')
            ->with('msg', 'Delete Successfully');
    }


    private function formValidate($request)
    {
        return Validator::make(
            $request->all(),
            [
                'name' => ['required'],
                'dob' => ['required', 'date'],
                'ssID' => ['required',
                    'size:11',
                    'starts-with:00,01,10,11',
                    function ($attribute, $value, $fail) {
                        $month = date('m', strtotime($value));
                        $year = date('y', strtotime($value));
                        if (($value[2] == $year[0]) && ($value[3] == $year[1]))
                        {
                            $fail('The next 4 digits are year of birth and month of birth');
                        }
                        elseif (($value[4] == $month[0]) && ($value[5] == $month[1]))
                        {
                            $fail('The next 4 digits are year of birth and month of birth');
                        }
                    }
                ],
                'selectedF'=>['required']
            ],
            [
                'selectedF.required'=>'please select a class'
            ]
        );
    }
}
