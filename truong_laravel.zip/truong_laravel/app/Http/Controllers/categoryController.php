<?php

namespace App\Http\Controllers;

use App\Repository\classRepos;
use App\Repository\shopuniform;
use App\Repository\teacherRepos;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class categoryController extends Controller
{
    public function index()
    {
        $cat = shopuniform::getAllcategory();
        return view('shop_uniform.index',
            [
                'cat' => $cat,
            ]);
    }
    public function create()
    {

        return view(
            'shop_uniform.new',
            ["cat" => (object)[
                'catID' => '',
                'name' => '',
                'img' => '',
                'description' => 0
            ]]);

    }
    public function show($id)
    {

        $cat  = shopuniform::getcatById($id); //this is always an array of objects
        return view('shop_uniform.show',
            [
                'cat' => $cat[0] //get the first element
            ]
        );
    }
    public function manager(Request $request)
    {
        if($request->has('file_upload')){
            $file = $request->file_upload;
            $ext=$request->file_upload->extension();
//            dd($ext);
            $file_name=time().'-'.'cat.'.$ext;
            $file->move(public_path('uploads'),$file_name);
        }
//        dd($request->all());
        $request->merge(['img'=> $file_name]);

        $this->formValidate($request)->validate(); //shortcut

        $cat  = (object)[
            'name' => $request->input('name'),
            'img' => $request->input('img'),
            'description' => $request->input('description'),
        ];

        $newId = shopuniform::insert($cat);

        return redirect()
            ->action('categoryController@index')
            ->with('msg', 'New category with id: '.$newId.' has been inserted');
    }
    public function edit($id)
    {
        $cat = shopuniform::getcatById($id); //this is always an array
        return view(
            'shop_uniform.update',
            ["cat" => $cat[0],
            ]);
    }
    public function update(Request $request, $id)
    {
        if ($id != $request->input('catID')) {
            //id in query string must match id in hidden input
            return redirect()->action('categoryController@index');
        }

        $this->formValidate($request)->validate(); //shortcut

        $teacher = (object)[
            'catID' => $request->input('catID'),
            'name' => $request->input('name'),
            'img' => $request->input('img'),
            'description' => $request->input('description'),
        ];
        shopuniform::update($teacher);

        return redirect()->action('categoryController@index')
            ->with('msg', 'Update Successfully');
    }
    public function confirm($id){
        $cat = shopuniform::getcatById($id); //this is always an array

        return view('shop_uniform.confirm',
            [
                'cat' => $cat[0],
            ]
        );
    }
    public function destroy(Request $request, $id)
    {
        if ($request->input('id') != $id) {
            //id in query string must match id in hidden input
            return redirect()->action('categoryController@index');
        }

        shopuniform::delete($id);


        return redirect()->action('categoryController@index')
            ->with('msg', 'Delete Successfully');
    }


    private function formValidate($request)
    {
        return Validator::make(
            $request->all(),
            [
                'name' => ['required'],
                'img' => ['required'],
                'description' => ['required']
            ],
            [
                //change validation message
                'name.required' => 'Please enter your first and last name'
            ]
        );
    }
}
