<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});
//
//Route::get('blade', function () {
//    return view('truong');
//});
//
//
Route::get('/', function () {
    return view('welcome');
});

Route::group(['prefix' => 'Homepage'], function () {
    Route::get('', function () {
        return view('Homepage.index');
    })->name('Homepage.index');

    Route::get('edit', function () {
        return view('book.edit');
    })->name('book.edit');

    Route::get('newBook', function () {
        return view('book.newBook');
    })->name('book.newBook');
});

Route::group(['prefix' => 'book'], function (){
    Route::get('reset',[
        'uses' => 'BookSessionController@resetBooks',
        'as' => 'book.reset'
    ]);

    Route::get('', [
        'uses' => 'BookSessionController@index',
        'as' => 'book.index'
    ]);

    Route::get('create',[
        'uses' => 'BookSessionController@create',
        'as' => 'book.create'
    ]);

    Route::post('create',[
        'uses' => 'BookSessionController@store',
        'as' => 'book.store'
    ]);

    Route::get('update/{id}',[
        'uses' => 'BookSessionController@edit',
        'as' => 'book.edit'
    ]);

    Route::post('update/{id}',[
        'uses' => 'BookSessionController@update',
        'as' => 'book.update'
    ]);

    Route::post('delete/{id}',[
        'uses' => 'BookSessionController@destroy',
        'as' => 'book.destroy'
    ]);
});

//Route::group(['prefix' => 'classRooms'], function () {
//    Route::get('', [
//        'uses' => 'ClassSessionController@index',
//        'as' => 'classRooms.index'
//    ]);
//
//    Route::get('create', [
//        'uses' => 'ClassSessionController@create',
//        'as' => 'classRooms.create'
//    ]);
//
//    Route::post('create', [
//        'uses' => 'ClassSessionController@manager',
//        'as' => 'classRooms.manager'
//    ]);
//
//    Route::get('update/{id}',[
//        'uses' => 'ClassSessionController@edit',
//        'as' => 'classRooms.edit'
//    ]);
//
//    Route::post('update/{id}',[
//        'uses' => 'ClassSessionController@update',
//        'as' => 'classRooms.update'
//    ]);
//
//    Route::post('delete/{id}',[
//        'uses' => 'ClassSessionController@destroy',
//        'as' => 'classRooms.destroy'
//    ]);
//});


//Route::group(['prefix' => 'teacher'], function () {
//    Route::get('', [
//        'uses' => 'TeacherSessionController@index',
//        'as' => 'teacher.index'
//    ]);
//
//    Route::get('create', [
//        'uses' => 'TeacherSessionController@create',
//        'as' => 'teacher.create'
//    ]);
//
//    Route::post('create', [
//        'uses' => 'TeacherSessionController@manager',
//        'as' => 'teacher.manager'
//    ]);
//
//    Route::get('update/{id}',[
//        'uses' => 'TeacherSessionController@edit',
//        'as' => 'teacher.edit'
//    ]);
//
//    Route::post('update/{id}',[
//        'uses' => 'TeacherSessionController@update',
//        'as' => 'teacher.update'
//    ]);
//
//    Route::post('delete/{id}',[
//        'uses' => 'TeacherSessionController@destroy',
//        'as' => 'teacher.destroy'
//    ]);
//});
//
//
//Route::group(['prefix' => 'student'], function () {
//    Route::get('', [
//        'uses' => 'StudentSessionController@index',
//        'as' => 'student.index'
//    ]);
//
//    Route::get('create', [
//        'uses' => 'StudentSessionController@create',
//        'as' => 'student.create'
//    ]);
//
//    Route::post('create', [
//        'uses' => 'StudentSessionController@manager',
//        'as' => 'student.manager'
//    ]);
//
//    Route::get('update/{id}',[
//        'uses' => 'StudentSessionController@edit',
//        'as' => 'student.edit'
//    ]);
//
//    Route::post('update/{id}',[
//        'uses' => 'StudentSessionController@update',
//        'as' => 'student.update'
//    ]);
//
//    Route::post('delete/{id}',[
//        'uses' => 'StudentSessionController@destroy',
//        'as' => 'student.destroy'
//    ]);
//});


Route::group(['prefix' => 'classroom'], function () {
    Route::get('', [
        'uses' => 'ClassControllerWithRepos@index',
        'as' => 'classRooms.index'
    ]);

    Route::get('show/{id}',[
        'uses' => 'ClassControllerWithRepos@show',
        'as' => 'classRooms.show'
    ]);

    Route::get('create',[
        'uses' => 'ClassControllerWithRepos@create',
        'as' => 'classRooms.create'
    ]);

    Route::post('create',[
        'uses' => 'ClassControllerWithRepos@manager',
        'as' => 'classRooms.manager'
    ]);

    Route::get('update/{id}',[
        'uses' => 'ClassControllerWithRepos@edit',
        'as' => 'classRooms.edit'
    ]);

    Route::post('update/{id}',[
        'uses' => 'ClassControllerWithRepos@update',
        'as' => 'classRooms.update'
    ]);

    Route::get('delete/{id}', [
        'uses' => 'ClassControllerWithRepos@confirm',
        'as' => 'classRooms.confirm'
    ]);

    Route::post('delete/{id}',[
        'uses' => 'ClassControllerWithRepos@destroy',
        'as' => 'classRooms.destroy'
    ]);
});
Route::group(['prefix' => 'teacher'], function () {
    Route::get('', [
        'uses' => 'teacherControllerWithRepos@index',
        'as' => 'teacher.index'
    ]);

    Route::get('show/{teacherID}',[
        'uses' => 'teacherControllerWithRepos@show',
        'as' => 'teacher.show'
    ]);

    Route::get('create',[
        'uses' => 'teacherControllerWithRepos@create',
        'as' => 'teacher.create'
    ]);

    Route::post('create',[
        'uses' => 'teacherControllerWithRepos@manager',
        'as' => 'teacher.manager'
    ]);

    Route::get('update/{teacherID}',[
        'uses' => 'teacherControllerWithRepos@edit',
        'as' => 'teacher.edit'
    ]);

    Route::post('update/{teacherID}',[
        'uses' => 'teacherControllerWithRepos@update',
        'as' => 'teacher.update'
    ]);

    Route::get('delete/{teacherID}', [
        'uses' => 'teacherControllerWithRepos@confirm',
        'as' => 'teacher.confirm'
    ]);

    Route::post('delete/{teacherID}',[
        'uses' => 'teacherControllerWithRepos@destroy',
        'as' => 'teacher.destroy'
    ]);
});


Route::group(['prefix' => 'shop_uniform'], function () {
    Route::get('', [
        'uses' => 'categoryController@index',
        'as' => 'category.index'
    ]);
    Route::get('show/{id}',[
        'uses' => 'categoryController@show',
        'as' => 'category.show'
    ]);

    Route::get('create',[
        'uses' => 'categoryController@create',
        'as' => 'category.create'
    ]);

    Route::post('create',[
        'uses' => 'categoryController@manager',
        'as' => 'category.manager'
    ]);

    Route::get('update/{id}',[
        'uses' => 'categoryController@edit',
        'as' => 'category.edit'
    ]);

    Route::post('update/{id}',[
        'uses' => 'categoryController@update',
        'as' => 'category.update'
    ]);

    Route::get('delete/{id}', [
        'uses' => 'categoryController@confirm',
        'as' => 'category.confirm'
    ]);

    Route::post('delete/{id}',[
        'uses' => 'categoryController@destroy',
        'as' => 'category.destroy'
    ]);
});


