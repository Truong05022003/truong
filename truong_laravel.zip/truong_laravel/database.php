<?php
define("DB_SERVER", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "1808g");

function db_connect() {
    $connection = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
    return $connection;
}

/******
 * Open connection to database
 */
$db = db_connect();
function db_disconnect($connection) { 
      mysqli_close($connection);
    }

    function confirm_query_result($result){
      global $db;
      if (!$result){
          echo mysqli_error($db);
          db_disconnect($db);
          exit; //terminate php
      } else {
          return $result;
      }
  }
  


function insert_Subject($subject) {
    global $db;

    $sql = " INSERT INTO  Subject ";
    $sql .= "(name, duration, level) ";
    $sql .= "VALUES ("; 
    $sql .= "'" . $subject['name'] . "',";
    $sql .= "'" . $subject['duration'] . "',";
    $sql .= "'" . $subject['level'] . "'";
    $sql .= ")";
    $result = mysqli_query($db, $sql);
 
    if($result) {
      return true;
    } else {
      echo mysqli_error($db);
      db_disconnect($db);
      exit; 
    }
}

function find_all_Subject(){
    global $db;

    $sql = "SELECT * FROM Subject ";
    $sql .= "ORDER BY name";
    //echo $sql;
    $result = mysqli_query($db, $sql); 
   
    return $result; 
}


function find_Subject_by_id($id) {
  global $db;

  $sql = "SELECT * FROM Subject ";
  $sql .= "WHERE subjectID='" . $id . "'";
  $result = mysqli_query($db, $sql);


  confirm_query_result($result);
  $subject = mysqli_fetch_assoc($result);
  mysqli_free_result($result);
  return $subject; // returns an assoc. array
}

function update_subject($subject) {
  global $db;

  $sql = "UPDATE Subject SET ";
  $sql .= "name='" . $subject['name'] . "', ";
  $sql .= "duration='" . $subject['duration'] . "', ";
  $sql .= "level='" . $subject['level'] . "' ";
  $sql .= "WHERE subjectID='" . $subject['subjectID'] . "' ";
  $sql .= "LIMIT 1";

  $result = mysqli_query($db, $sql);
  // For UPDATE statements, $result is true/false
  // if($result) {
  //   return true;
  // } else {
  //   // UPDATE failed
  //   echo mysqli_error($db);
  //   db_disconnect($db);
  //   exit;
  // }
  return confirm_query_result($result);
}

function delete_subject($subject) {
  global $db;
  $sql = "DELETE FROM Subject ";
  $sql .= "WHERE subjectID='" . $subject["subjectID"] . "' ";
  $sql .= "LIMIT 1";
  $result = mysqli_query($db, $sql);
  return confirm_query_result($result);
}


?>