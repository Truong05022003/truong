<?php $__env->startSection('main'); ?>


  <div class="container">
    <h1 class="display-4">Book Details</h1>
    <?php echo $__env->make('shop_uniform.categoryDetails', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <a type="button" href="<?php echo e(route('category.index')); ?>" class="btn btn-info">&lt;&lt;&nbsp;Index</a>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.uniformMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/shop_uniform/show.blade.php ENDPATH**/ ?>