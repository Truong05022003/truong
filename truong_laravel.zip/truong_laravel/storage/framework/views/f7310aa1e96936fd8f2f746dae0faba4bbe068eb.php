<?php $__env->startSection('main'); ?>
   <div class="container">
      <h1 class="display-4">Update An Existing Category</h1>

      

      <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <form action="<?php echo e(route('category.update', ['id' => old('catID')?? $cat->catID])); ?>" method="post">
         <?php echo csrf_field(); ?>

         <input type="hidden" name="catID" value="<?php echo e(old('catID')?? $cat->catID); ?>">
         <div class="form-group">
            <label for="name" class="font-weight-bold">name</label>
            <input type="text" class="form-control" id="name" name="name"
                   value="<?php echo e(old('name')?? $cat->name); ?>">
         </div>

         <div class="form-group">
            <label for="img" class="font-weight-bold">img</label>
            <input type="file" class="form-control" id="img" name="img"
                   value="<?php echo e(old('img')?? $cat->img); ?>">
         </div>

         <div class="form-group">
            <label for="description" class="font-weight-bold">description</label>
            <input type="text" class="form-control" id="Size" name="description"
                   value="<?php echo e(old('description')?? $cat->description); ?>">
         </div>
         <br>
         <button type="submit" class="btn btn-primary">Update</button>
         <button type="reset" class="btn btn-secondary">Reset</button>

      </form>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.uniformMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/shop_uniform/update.blade.php ENDPATH**/ ?>