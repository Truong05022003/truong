<?php if(\Illuminate\Support\Facades\Session::get('msg') != null): ?>
  
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(\Illuminate\Support\Facades\Session::get('msg')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/classRoom/classSession/mess.blade.php ENDPATH**/ ?>