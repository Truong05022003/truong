<?php $__env->startSection('main'); ?>
  <div class="container">
    <h1>Class</h1>
    <table class="table">
      <tr class="bg-dark text-white">
        <th>ID</th>
        <th>name</th>
        <th>Start Date</th>
        <th>Size</th>
        <th>&nbsp;</th>
        <th>&nbsp;</th>
      </tr>
      <tr>
        <tbody>
        <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            
            <td><?php echo e($c['name']); ?></td>
            <td><?php echo e($c['StartDate']); ?></td>
            <td><?php echo e($c['Size']); ?></td>
            <td><a type="button" class="btn btn-success btn-sm"  href="<?php echo e(route('class.edit', ['name' => $c['name']])); ?>" >edit</a></td>
            <td><a type="button" class="btn btn-danger  btn-sm" data-class="<?php echo e(join('|',$c)); ?>" data-toggle="modal" data-target="#deleteclass">Delete</a></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
  </div>
<div class="modal fade" tabindex="-1" id="deleteclass" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Deleting Class</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>


      <form id="deleteForm" method="post">
        <?php echo csrf_field(); ?>
        <div class="modal-body">
            <div class="form-group">
              <label for="name">name</label>
              <input type="text" class="form-control" id="name" name="name">
            </div>

            <div class="form-group">
              <label for="StartDate">Start Date</label>
              <input type="date" class="form-control" id="Start Date" name="StartDate">
            </div>

            <div class="form-group">
              <label for="Size">Size</label>
              <input type="number" class="form-control" id="Size" name="Size">
            </div>
        </div>
        <div class="modal-footer">
          <input type="submit" class="btn btn-primary" value="Delete">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        </div>
      </form>

    </div>

  </div>
</div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <script type="text/javascript">
    $('document').ready(function () {
      $('a[data-class]').on('click', function (evt) {
        let bData = $(this).attr('data-class').split("|");
        console.log(bData);
        $('#name').attr('value', bData[0]);
        $('#StartDate').attr('value', bData[1]);
        $('#Size').attr('value', bData[2]);

        $('#deleteForm').attr('action', bData[4]);
      });
    });
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('masters.pieMasters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/school/classroom/indexclass.blade.php ENDPATH**/ ?>