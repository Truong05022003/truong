<?php $__env->startSection('main'); ?>
  <div class="container">
    <h1>Book Index</h1>
    <table class="table">
      <tr class="bg-dark text-white">
        <th>#</th>
        <th>Title</th>
        <th>Author</th>
        <th>Pages</th>
        <th>&nbsp;</th>
        <th>&nbsp;</th>
      </tr>
      <tr>
        <td>1</td>
        <td>PHP for Dummies</td>
        <td> Green Hulk</td>
        <td>431</td>
        <td> <a class=" bg-success text-white" href="<?php echo e(route('pie.update')); ?>"> edit</a> </td>
        <td><a href="#" data-toggle="modal" data-target="#deletemodal" class="bg-danger text-white"> delete </a> </td>
      </tr>
      <tr>
        <td>2</td>
        <td>Getting Started with Lavavel </td>
        <td> Iron Man</td>
        <td>209</td>
        <td> <a class=" bg-success text-white" href="<?php echo e(route('pie.update')); ?>"> edit</a> </td>
        <td><a href="#" data-toggle="modal" data-target="#deletemodal" class="bg-danger text-white"> delete </a> </td>
      </tr>
      <tr>
        <td>3</td>
        <td>Advanced Lavavel</td>
        <td> Black Widow</td>
        <td>559</td>
        <td> <a class=" bg-success text-white" href="<?php echo e(route('pie.update')); ?>"> edit</a> </td>
        <td><a href="#" data-toggle="modal" data-target="#deletemodal" class="bg-danger text-white"> delete </a> </td>
      </tr>
    </table>

  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('other'); ?>
  <div class="modal fade" tabindex="-1" id="deletemodal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Deleting A Book</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form>
            <div class="form-group">
              <label for="title">Title</label>
              <input type="text" class="form-control" id="title" aria-describedby="" placeholder="">
            </div>
            <div class="form-group">
              <label for="author">Author</label>
              <input type="text" class="form-control" id="author" placeholder="">
            </div>

            <div class="form-group">
              <label for="page">Page</label>
              <input type="number" class="form-control" id="page" placeholder="">
            </div>

          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Delete</button>
          <button type="button" class="btn btn-primary">Cancel</button>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.pieMasters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/pie/index.blade.php ENDPATH**/ ?>