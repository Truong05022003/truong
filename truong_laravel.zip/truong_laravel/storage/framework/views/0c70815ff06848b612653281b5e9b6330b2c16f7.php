<?php $__env->startSection('main'); ?>
  <div class="container">

    <br>
    <table class="table table-hover">
      <thead class="thead-dark">
      <tr>
        <th scope="col">#</th>
        <th scope="col">Name </th>
        <th scope="col">img</th>
        <th scope="col">description</th>
        <th scope="col">&nbsp;</th>
        <th scope="col">&nbsp;</th>
        <th scope="col">&nbsp;</th>
      </tr>
      </thead>
      <tbody>
      <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <th scope="row"><?php echo e($c->catID); ?></th>
          <td><?php echo e($c->name); ?></td>
          <td> <img src="<?php echo e(url('uploads')); ?>/<?php echo e($c->img); ?>" width="60"></td>
          <td><?php echo e($c->description); ?></td>
          <td><a type="button" class="btn btn-primary btn-sm"
                 href="<?php echo e(route('category.show', ['id' => $c->catID])); ?>"
            >Details</a>
          <td><a type="button" class="btn btn-success btn-sm"
                 href="<?php echo e(route('category.edit', ['id' => $c->catID])); ?>"
            >Edit</a></td>
          <td><a type="button" class="btn btn-danger btn-sm"
                 href="<?php echo e(route('category.confirm', ['id' => $c->catID])); ?>"
            >Delete</a></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.uniformMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/shop_uniform/index.blade.php ENDPATH**/ ?>