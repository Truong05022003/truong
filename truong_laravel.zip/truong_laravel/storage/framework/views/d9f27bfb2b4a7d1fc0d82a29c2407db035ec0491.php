<?php $__env->startSection('main'); ?>
  <div class="container">
    <h1> New Book</h1>
  <h1> New Book</h1>
    <label for="duration">name</label>
    <input type="text" id="name" name="name"
           value="">
  <br><br>
    <label for="duration">author</label>
    <input type="text" id="author" name="author"
         value="">
  <br><br>
    <label for="level">pages</label>
    <input type="number" id="author" name="author"
           value="">
  <br><br>
    <input type="submit" name="submit" value="Submit">
    <input type="reset" name="reset" value="Reset">
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.pieMasters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/pie/newbook.blade.php ENDPATH**/ ?>