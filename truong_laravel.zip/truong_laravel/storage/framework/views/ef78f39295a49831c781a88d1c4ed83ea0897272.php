<?php $__env->startSection('main'); ?>
  <div class="container">
    <h1> New Book</h1>
    <h1> New Class</h1>
    <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(route('class.store')); ?>" method="post">
      <?php echo csrf_field(); ?>
    <label for="name">name</label>
    <input type="text" id="name" name="name"
           value="">
    <br><br>
    <label for="StartDate">StartDate</label>
    <input type="date" id="author" name="StartDate"
           value="">
    <br><br>
    <label for="Size">Size</label>
    <input type="number" id="author" name="Size"
           value="">
    <br><br>
    <input type="submit" name="submit" value="Submit">
    <input type="reset" name="reset" value="Reset">
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.pieMasters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/school/classroom/newclass.blade.php ENDPATH**/ ?>