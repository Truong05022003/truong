<dl class="row">
  <dt class="col-sm-3">ID</dt>
  <dd class="col-sm-9"><?php echo e($class->id); ?></dd>

  <dt class="col-sm-3">Title</dt>
  <dd class="col-sm-9"><?php echo e($class->NAME); ?></dd>

  <dt class="col-sm-3">Author</dt>
  <dd class="col-sm-9"><?php echo e($class->StartDate); ?></dd>

  <dt class="col-sm-3">Pages</dt>
  <dd class="col-sm-9"><?php echo e($class->Size); ?></dd>
</dl>
<?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/classRoom/classSession/categoryDetails.blade.php ENDPATH**/ ?>
