<dl class="row">
  <dt class="col-sm-3">ID</dt>
  <dd class="col-sm-9"><?php echo e($teacher->teacherID); ?></dd>

  <dt class="col-sm-3">Title</dt>
  <dd class="col-sm-9"><?php echo e($teacher->name); ?></dd>

  <dt class="col-sm-3">Author</dt>
  <dd class="col-sm-9"><?php echo e($teacher->dob); ?></dd>

  <dt class="col-sm-3">Pages</dt>
  <dd class="col-sm-9"><?php echo e($teacher->ssID); ?></dd>

  <dt class="col-sm-3">class</dt>
  <dd class="col-sm-9">
    <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row">
        <div class="col-sm"><?php echo e($c->NAME); ?></div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </dd>
</dl>
<?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/teacherManager/teacherDetails.blade.php ENDPATH**/ ?>