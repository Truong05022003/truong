<?php $__env->startSection('main'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.HomePageMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/Homepage/index.blade.php ENDPATH**/ ?>