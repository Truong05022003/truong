<?php $__env->startSection('main'); ?>
  <div class="container">
    <h1 class="display-4">Are you sure you want to delete?</h1>
    <?php echo $__env->make('teacherManager.teacherDetails', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <form action="<?php echo e(route('teacher.destroy', ['teacherID' =>$teacher->teacherID])); ?>" method="post">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="teacherID" value="<?php echo e($teacher->teacherID); ?>">
      <button type="submit" class="btn btn-danger">Delete</button>
      <a href="<?php echo e(route('teacher.index')); ?>" class="btn btn-info">Cancel</a>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.teacherMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/teacherManager/confirm.blade.php ENDPATH**/ ?>