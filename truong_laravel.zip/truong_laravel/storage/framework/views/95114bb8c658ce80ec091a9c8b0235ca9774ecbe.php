<dl class="row">
  <dt class="col-sm-3">ID</dt>
  <dd class="col-sm-9"><?php echo e($student->id); ?></dd>

  <dt class="col-sm-3">Title</dt>
  <dd class="col-sm-9"><?php echo e($student->name); ?></dd>

  <dt class="col-sm-3">Author</dt>
  <dd class="col-sm-9"><?php echo e($student->email); ?></dd>

  <dt class="col-sm-3">Pages</dt>
  <dd class="col-sm-9"><?php echo e($student->contact); ?></dd>

  <dt class="col-sm-3">class</dt>
  <dd class="col-sm-9"><?php echo e($class->NAME); ?></dd>
</dl>
<?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/studentManager/studentDetails.blade.php ENDPATH**/ ?>