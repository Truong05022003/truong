<?php $__env->startSection('main'); ?>
  <div class="container">
    <h1> New Book</h1>
    <h1> Update An existing Book </h1>
    <label for="duration">name</label>
    <input type="text" id="name" name="name"
           value="Introduction to Nothing">
    <br><br>
    <label for="duration">author</label>
    <input type="text" id="author" name="author"
           value="Unknown Author">
    <br><br>
    <label for="level">pages</label>
    <input type="number" id="author" name="author"
           value="99999">
    <br><br>
    <input type="submit" name="submit" value="Submit">
    <input type="reset" name="reset" value="Reset">
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('other'); ?>
  <div class="modal fade" tabindex="-1" id="deletemodal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Deleting A Book</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form>
            <div class="form-group">
              <label for="title">Title</label>
              <input type="text" class="form-control" id="title" aria-describedby="" placeholder="">
            </div>
            <div class="form-group">
              <label for="author">Author</label>
              <input type="text" class="form-control" id="author" placeholder="">
            </div>

            <div class="form-group">
              <label for="page">Page</label>
              <input type="number" class="form-control" id="page" placeholder="">
            </div>

          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Delete</button>
          <button type="button" class="btn btn-primary"></a>Cancel</button>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.pieMasters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/pie/update.blade.php ENDPATH**/ ?>