<?php $__env->startSection('main'); ?>
  <div class="container">
    <h1 class="display-4">New ClassRoom</h1>

    <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <form action="<?php echo e(route('category.manager')); ?>" method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="name" class="font-weight-bold">Name </label>
        <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>">
      </div>

      <div class="form-group">
        <label for="img" class="font-weight-bold">img</label>
        <input type="file" class="form-control" id="img" name="file_upload" value="<?php echo e(old('img')); ?>">
      </div>

      <div class="form-group">
        <label for="description" class="font-weight-bold">description</label>
        <input type="text" class="form-control" id="description" name="description" value="<?php echo e(old('description')); ?>">
      </div>
      <br>
      <button type="submit" class="btn btn-primary">Add new classroom</button>
      <button type="reset" class="btn btn-secondary">Reset</button>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.uniformMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/shop_uniform/new.blade.php ENDPATH**/ ?>