<?php $__env->startSection('main'); ?>
   <div class="container">
     <?php echo $__env->make('studentManager.mess', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <br>
      <table class="table table-hover">
         <thead class="thead-dark">
         <tr>
            <th scope="col">#</th>
            <th scope="col">Name Student</th>
            <th scope="col">Email</th>
            <th scope="col">Contact</th>
           <th scope="col">class</th>
            <th scope="col">&nbsp;</th>
            <th scope="col">&nbsp;</th>
           <th scope="col">&nbsp;</th>
         </tr>
         </thead>
         <tbody>
         <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <th scope="row"><?php echo e($s->id); ?></th>
               <td><?php echo e($s->name); ?></td>
               <td><?php echo e($s->email); ?></td>
               <td><?php echo e($s->contact); ?></td>
              <td><?php echo e($s->className); ?></td>
              <td><a type="button" class="btn btn-primary btn-sm"
                     href="<?php echo e(route('student.show', ['id' => $s->id])); ?>"
                >Details</a>
               <td><a type="button" class="btn btn-success btn-sm"
                      href="<?php echo e(route('student.edit', ['id' => $s->id])); ?>">Edit</a></td>
               <td><a type="button" class="btn btn-danger btn-sm"
                     href="<?php echo e(route('student.confirm', ['id' => $s->id])); ?>"
                      >Delete</a></td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>
   <a href="<?php echo e(route('student.create')); ?>">Create new student</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.studentMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/studentManager/index.blade.php ENDPATH**/ ?>