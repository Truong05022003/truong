<?php $__env->startSection('main'); ?>
   <div class="container">
     <?php echo $__env->make('classRoom.classSession.mess', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <br>
      <table class="table table-hover">
         <thead class="thead-dark">
         <tr>
            <th scope="col">#</th>
            <th scope="col">Name Class</th>
            <th scope="col">Start Date</th>
            <th scope="col">Size</th>
            <th scope="col">&nbsp;</th>
            <th scope="col">&nbsp;</th>
            <th scope="col">&nbsp;</th>
         </tr>
         </thead>
         <tbody>
         <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <th scope="row"><?php echo e($c->id); ?></th>
               <td><?php echo e($c->NAME); ?></td>
               <td><?php echo e($c->StartDate); ?></td>
               <td><?php echo e($c->Size); ?></td>
              <td><a type="button" class="btn btn-primary btn-sm"
                     href="<?php echo e(route('classRooms.show', ['id' => $c->id])); ?>"
                >Details</a>
              </td>
               <td><a type="button" class="btn btn-success btn-sm"
                      href="<?php echo e(route('classRooms.edit', ['id' => $c->id])); ?>">Edit</a></td>
               <td><a type="button" class="btn btn-danger btn-sm"
                      href="<?php echo e(route('classRooms.confirm', ['id' => $c->id])); ?>">Delete</a></td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>
   <a href="<?php echo e(route('classRooms.create')); ?>">Create new classroom</a>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('masters.classRoomMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/classRoom/classSession/index.blade.php ENDPATH**/ ?>