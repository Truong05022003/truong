<?php $__env->startSection('main'); ?>
  <div class="container">
    <h1 class="display-4">Are you sure you want to delete?</h1>
    <?php echo $__env->make('classRoom.classSession.classDetails', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <form action="<?php echo e(route('classRooms.destroy', ['id' =>$class->id])); ?>" method="post">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="id" value="<?php echo e($class->id); ?>">
      <button type="submit" class="btn btn-danger">Delete</button>
      <a href="<?php echo e(route('classRooms.index')); ?>" class="btn btn-info">Cancel</a>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.classRoomMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/classRoom/classSession/confirm.blade.php ENDPATH**/ ?>