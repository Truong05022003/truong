<?php $__env->startSection('main'); ?>
   <div class="container">
      <h1 class="display-4">Update An Existing ClassRoom</h1>

      

      <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <form action="<?php echo e(route('classRooms.update', ['id' => old('id')?? $class->id])); ?>" method="post">
         <?php echo csrf_field(); ?>

         <input type="hidden" name="id" value="<?php echo e(old('id')?? $class->id); ?>">
         <div class="form-group">
            <label for="NAME" class="font-weight-bold">Name ClassRoom</label>
            <input type="text" class="form-control" id="NAME" name="NAME"
                   value="<?php echo e(old('NAME')?? $class->NAME); ?>">
         </div>

         <div class="form-group">
            <label for="StartDate" class="font-weight-bold">Start Date</label>
            <input type="date" class="form-control" id="StartDate" name="StartDate"
                   value="<?php echo e(old('StartDate')?? $class->StartDate); ?>">
         </div>

         <div class="form-group">
            <label for="Size" class="font-weight-bold">Size</label>
            <input type="number" class="form-control" id="Size" name="Size"
                   value="<?php echo e(old('Size')?? $class->Size); ?>">
         </div>
         <br>
         <button type="submit" class="btn btn-primary">Update ClassRoom</button>
         <button type="reset" class="btn btn-secondary">Reset</button>

      </form>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.classRoomMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/classRoom/classSession/update.blade.php ENDPATH**/ ?>