<?php $__env->startSection('main'); ?>


  <div class="container">
    <h1 class="display-4">Book Details</h1>
    <?php echo $__env->make('teacherManager.teacherDetails', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <a type="button" href="<?php echo e(route('teacher.index')); ?>" class="btn btn-info">&lt;&lt;&nbsp;Index</a>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.teacherMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/teacherManager/show.blade.php ENDPATH**/ ?>