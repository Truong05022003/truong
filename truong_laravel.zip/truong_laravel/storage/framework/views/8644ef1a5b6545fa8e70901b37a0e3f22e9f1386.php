<dl class="row">
  <dt class="col-sm-3">ID</dt>
  <dd class="col-sm-9"><?php echo e($cat->catID); ?></dd>

  <dt class="col-sm-3">name</dt>
  <dd class="col-sm-9"><?php echo e($cat->name); ?></dd>

  <dt class="col-sm-3">Img</dt>
  <dd class="col-sm-9"><img src="<?php echo e(url('uploads')); ?>/<?php echo e($cat->img); ?>" width="200"></dd>

  <dt class="col-sm-3">description</dt>
  <dd class="col-sm-9"><?php echo e($cat->description); ?></dd>
</dl>
<?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/shop_uniform/categoryDetails.blade.php ENDPATH**/ ?>