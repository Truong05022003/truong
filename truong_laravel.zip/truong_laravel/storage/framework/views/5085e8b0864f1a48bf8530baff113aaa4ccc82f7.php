<?php $__env->startSection('main'); ?>
  <div class="container">
    <h1 class="display-4">Are you sure you want to delete?</h1>
    <?php echo $__env->make('studentManager.studentDetails', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <form action="<?php echo e(route('student.destroy', ['id' =>$student->id])); ?>" method="post">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="id" value="<?php echo e($student->id); ?>">
      <button type="submit" class="btn btn-danger">Delete</button>
      <a href="<?php echo e(route('student.index')); ?>" class="btn btn-info">Cancel</a>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.studentMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/studentManager/confirm.blade.php ENDPATH**/ ?>