<?php $__env->startSection('main'); ?>


  <div class="container">
    <h1 class="display-4">Book Details</h1>
    <?php echo $__env->make('studentManager.studentDetails', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <a type="button" href="<?php echo e(route('student.index')); ?>" class="btn btn-info">&lt;&lt;&nbsp;Index</a>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.studentMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/studentManager/show.blade.php ENDPATH**/ ?>