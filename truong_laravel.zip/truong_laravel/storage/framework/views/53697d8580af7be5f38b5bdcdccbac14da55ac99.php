<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
   <div class="container">
      <a class="navbar-brand" href="<?php echo e(route('classRooms.index')); ?>">CLASSROOM MANAGER</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse"
              aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
      </button>
   </div>
</nav>
<?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/partials/classRoomNav.blade.php ENDPATH**/ ?>