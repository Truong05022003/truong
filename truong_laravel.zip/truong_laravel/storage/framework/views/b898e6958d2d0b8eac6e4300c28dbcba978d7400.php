<?php $__env->startSection('main'); ?>
   <div class="container">
      <h1 class="display-4">New Teacher</h1>

      <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <form action="<?php echo e(route('teacher.manager')); ?>" method="post">
         <?php echo csrf_field(); ?>
         <div class="form-group">
            <label for="name" class="font-weight-bold">Teacher Name</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>">
         </div>

         <div class="form-group">
            <label for="dob" class="font-weight-bold">Date of Birth</label>
            <input type="date" class="form-control" id="dob" name="dob" value="<?php echo e(old('dob')); ?>">
         </div>

         <div class="form-group">
            <label for="ssID" class="font-weight-bold">ssID</label>
            <input type="number" class="form-control" id="ssID" name="ssID" value="<?php echo e(old('ssID')); ?>">
         </div>
        <?php
          $fIds = old('selectedF')?? array_column($selectedF, 'id') ?? array();
        ?>
        <div class="form-group">
          <label class="font-weight-bold mr-3">class</label>
          <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" value="<?php echo e($c->id); ?>" id="<?php echo e($c->NAME); ?>" name="selectedF[]"
                <?php echo e(in_array($c->id, $fIds) ? 'checked' : ''); ?>

              >
              <label class="form-check-label" for="<?php echo e($c->NAME); ?>">
                <?php echo e($c->NAME); ?>

              </label>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

         <br>
         <button type="submit" class="btn btn-primary">Add new teacher</button>
         <button type="reset" class="btn btn-secondary">Reset</button>
      </form>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.teacherMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/teacherManager/new.blade.php ENDPATH**/ ?>