<?php $__env->startSection('main'); ?>
   <div class="container">
      <h1 class="display-4">Update An Existing Teacher</h1>

      

      <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <form action="<?php echo e(route('teacher.update', ['teacherID' => old('teacherID')?? $teacher->teacherID])); ?>" method="post">
         <?php echo csrf_field(); ?>
         <input type="hidden" name="teacherID" value="<?php echo e(old('teacherID')?? $teacher->teacherID); ?>">
         <div class="form-group">
            <label for="name" class="font-weight-bold">Teacher Name</label>
            <input type="text" class="form-control" id="name" name="name"
                   value="<?php echo e(old('name')?? $teacher->name); ?>">
         </div>

         <div class="form-group">
            <label for="dob" class="font-weight-bold">Date of Birth</label>
            <input type="date" class="form-control" id="dob" name="dob"
                   value="<?php echo e(old('dob')?? $teacher->dob); ?>">
         </div>

         <div class="form-group">
            <label for="ssID" class="font-weight-bold">ssID</label>
            <input type="number" class="form-control" id="ssID" name="ssID"
                   value="<?php echo e(old('ssID')?? $teacher->ssID); ?>">
         </div>
        <?php
          $fIds = old('selectedF')?? array_column($selectedF, 'id') ?? array();
        ?>
        <div class="form-group">
          <label class="font-weight-bold mr-3">class</label>
          <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" value="<?php echo e($c->id); ?>" id="<?php echo e($c->NAME); ?>" name="selectedF[]"
                <?php echo e(in_array($c->id, $fIds) ? 'checked' : ''); ?>

              >
              <label class="form-check-label" for="<?php echo e($c->NAME); ?>">
                <?php echo e($c->NAME); ?>

              </label>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
         <br>
         <button type="submit" class="btn btn-primary">Update Teacher</button>
         <button type="reset" class="btn btn-secondary">Reset</button>

      </form>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.teacherMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/teacherManager/update.blade.php ENDPATH**/ ?>