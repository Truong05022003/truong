<?php $__env->startSection('main'); ?>
   <div class="container">
     <?php echo $__env->make('teacherManager.mess', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <br>
      <table class="table table-hover">
         <thead class="thead-dark">
         <tr>
            <th scope="col">#</th>
            <th scope="col">Teacher Name</th>
            <th scope="col">Date of Birth</th>
            <th scope="col">ssID</th>
            <th scope="col">&nbsp;</th>
            <th scope="col">&nbsp;</th>
            <th scope="col">&nbsp;</th>
         </tr>
         </thead>
         <tbody>
         <?php $__currentLoopData = $teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <th scope="row"><?php echo e($t->teacherID); ?></th>
               <td><?php echo e($t->name); ?></td>
               <td><?php echo e($t->dob); ?></td>
               <td><?php echo e($t->ssID); ?></td>
              <td><a type="button" class="btn btn-primary btn-sm"
                     href="<?php echo e(route('teacher.show', ['teacherID' => $t->teacherID])); ?>"
                >Details</a>
               <td><a type="button" class="btn btn-success btn-sm"
                      href="<?php echo e(route('teacher.edit', ['teacherID' => $t->teacherID])); ?>"
                 >Edit</a></td>
               <td><a type="button" class="btn btn-danger btn-sm"
                      href="<?php echo e(route('teacher.confirm', ['teacherID' => $t->teacherID])); ?>"
                 >Delete</a></td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>
   <a href="<?php echo e(route('teacher.create')); ?>">Create new teacher</a>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('masters.teacherMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nguyen truong\truong_laravel\resources\views/teacherManager/index.blade.php ENDPATH**/ ?>