<?php
require_once('database.php');
require_once('functions.php');

if ($_SERVER["REQUEST_METHOD"] == 'POST'){
    //db delete
    delete_subject($_POST['subjectID']);

    redirect_to('index.php');
} else { // form loaded
    if(!isset($_GET['subjectID'])) {
        redirect_to('index.php');
    }


    $id = $_GET['subjectID'];
    $subject = find_subject_by_id($id);
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Delete Book</title>
    <style>
        .label {
            font-weight: bold;
            font-size: large;
        }
    </style>
</head>
<body>
    <h1>Delete Subject</h1>
    <h2>Are you sure you want to delete this subject?</h2>
    <p><span class="label">Subject: </span><?php echo $subject['name']; ?></p>
    <p><span class="label">Duration: </span><?php echo $subject['duration']; ?></p>
    <p><span class="label">Level: </span><?php echo $subject['level']; ?></p>
    <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
        <input type="hidden" name="subjectID" value="<?php echo $subject['subjectID']; ?>" >
     
        <input type="submit" name="submit" value="Delete Subject">
     
    </form>
    
    <br><br>
    <a href="index.php">Back to index</a> 
</body>
</html>


<?php
db_disconnect($db);
?>